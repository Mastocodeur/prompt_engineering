# 🛡️ Attaques sur LLM – Prompt Engineering appliqué à Gandalf (Lakera)


| Navigation |
|------------|
| [![🧠 Techniques](https://img.shields.io/badge/-Techniques-blue?style=for-the-badge)](TECHNIQUES.md) |
| [![🧪 Solutions](https://img.shields.io/badge/-Solutions-green?style=for-the-badge)](SOLUTIONS.md) |



Ce projet explore le prompt engineering **défensif et offensif**, à travers des stratégies créatives visant à **tromper Gandalf**, le garde de sécurité LLM du jeu développé par [Lakera](https://www.lakera.ai/).

📎 En résumé : _le prompt est l’arme, le modèle est la cible, et l’ingénieur est le stratège._

Pour les bases du prompt engineering, voir la [fiche récapitulative](../FICHE.md).

## 🧨 Définition d’une prompt injection ?

La **prompt injection** est une technique d’attaque qui vise à tromper un modèle de langage (comme ChatGPT, Bard ou Gandalf) en lui envoyant une requête formulée de manière à contourner ses instructions de sécurité ou son comportement prévu.

Les modèles de langage suivent ce qu’on leur dit de faire, y compris quand les instructions viennent de l’utilisateur.

Cela peut être utilisé pour :

* Contourner des filtres de modération (profanités, contenu toxique, etc.),
* Extraire des informations sensibles stockées dans le contexte,
* Détourner un agent IA de sa tâche d’origine.

La prompt injection n’est pas qu’un jeu ou une curiosité de laboratoire.
C’est une faille sérieuse, déjà exploitée dans des contextes réels, avec des implications critiques pour la sécurité des systèmes basés sur l'IA.
Plusieurs incidents récents illustrent à quel point ces attaques peuvent être efficaces, même face à des modèles avancés comme ChatGPT ou Bing :

* 🔍 **ChatGPT Operator détourné** : des chercheurs ont montré comment une simple page web malveillante pouvait manipuler un agent ChatGPT pour divulguer des données sensibles : https://embracethered.com/blog/posts/2025/chatgpt-operator-prompt-injection-exploits

* 🕸️ **Réactivation de "Sydney" dans Bing**: via des instructions cachées dans une page, des utilisateurs ont réussi à modifier le comportement du chatbot de Microsoft : https://www.wired.com/story/chatgpt-prompt-injection-attack-security

* 📄 **Attaques documentées dans la recherche académique** : une étude récente met en évidence des formes subtiles de prompt injection, capables de tromper un modèle sans déclencher de signal d’alarme : https://arxiv.org/abs/2504.16125




## Sources

Voir la liste complète des sources dans le [README principal](../README.md#sources--credits).

