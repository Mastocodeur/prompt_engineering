# Prompt Engineering

[![Francais](https://img.shields.io/badge/lang-Fran%C3%A7ais-red)](README.md)

> A reference repository on prompt engineering: principles, techniques, hands-on exercises, and LLM security.

---

## Table of Contents

- [Cheat Sheet](#-cheat-sheet)
- [Fundamentals](#-fundamentals)
- [Security & Prompt Injection](#-security--prompt-injection)
- [Sources & Credits](#-sources--credits)

---

## Cheat Sheet

**[FICHE.md](FICHE.md)** — Comprehensive prompt engineering cheat sheet (in French):

- Core principles (clear instructions, reasoning)
- Techniques: few-shot, chain-of-thought, role prompting, constraint prompting
- Iterative prompting
- Common pitfalls and solutions
- Summarization, inference, transformation
- Hallucination management

---

## Fundamentals

**[fondamentaux/](fondamentaux/)** — 7 notebooks from the [ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) course by DeepLearning.AI.

| # | Notebook | Topic |
|---|----------|-------|
| 01 | Guidelines | Core principles |
| 02 | Iterative Prompt Development | Iterative process |
| 03 | Summarizing | Summarization techniques |
| 04 | Inferring | Sentiment, classification |
| 05 | Transforming | Translation, tone, format |
| 06 | Expanding | Text generation |
| 07 | Chatbot | Chatbot with context |

---

## Security & Prompt Injection

**[securite/](securite/)** — Offensive and defensive prompt engineering through [Gandalf](https://gandalf.lakera.ai/) by Lakera.

- [**Introduction & context**](securite/README.md) — What is prompt injection? Real-world incidents.
- [**Attack techniques**](securite/TECHNIQUES.md) — Toolkit: ~30 classified techniques (direct injection, jailbreak, obfuscation, encoding, etc.)
- [**Gandalf Solutions**](securite/SOLUTIONS.md) — Full walkthrough: levels 1-8 + variants (Summarizer, Truthteller, Reverse, Tongue Tied)

---

## Sources & Credits

### Courses

- [ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) — DeepLearning.AI (Andrew Ng & Isa Fulford)

### AI Security

- [Gandalf](https://gandalf.lakera.ai/) — Lakera
- [Prompt Guard (fine-tuned)](https://huggingface.co/skshreyas714/prompt-guard-finetuned) — HuggingFace

### Guides & Resources

- [Prompt Engineering Guide](https://github.com/dair-ai/Prompt-Engineering-Guide) — DAIR.AI
- [Awesome GPT Prompts](https://www.awesomegptprompts.com/)
- [Prompt Guide](https://docs.perplexity.ai/docs/agent-api/prompt-guide) — Perplexity AI
- [GPT Prompts for Data](https://notion.castordoc.com/gpt-prompts) — CastorDoc
