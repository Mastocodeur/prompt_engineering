# Fiche sur le prompt engineering

## Sommaire

- [Définition](#définition)

- [Concepts fondamentaux](#concepts-fondamentaux)
  - [System prompt vs User prompt](#system-prompt-vs-user-prompt)
  - [Temperature et paramètres](#temperature-et-paramètres)

- [Les grands principes](#les-grands-principes)
  - [Principe 0 : Faire attention aux hallucinations](#principe-0--faire-attention-aux-hallucinations)
  - [Principe 1 : Write clear and specific instructions](#principe-1--write-clear-and-specific-instructions)
  - [Principe 2 : Give the model time to "think"](#principe-2--give-the-model-time-to-think)

- [Les techniques](#les-techniques)
  - [Pour la clarté](#pour-la-clarté)
  - [Pour le raisonnement](#pour-le-raisonnement)

- [Prompting Itératif](#prompting-itératif)

- [Problèmes fréquents et solutions](#problèmes-fréquents-et-solutions)
  - [Problème 1 : Réponse trop longue](#problème-1--réponse-trop-longue)
  - [Problème 2 : Mauvais focus](#problème-2--mauvais-focus)
  - [Problème 3 : Besoin d'un tableau](#problème-3--besoin-dun-tableau)

- [Résumé (Summarization)](#résumé-summarization)

- [Inférence](#inférence)

- [Transformation](#transformation)

- [Techniques avancées](#techniques-avancées)

- [Gestion des Hallucinations](#gestion-des-hallucinations)

- [Sources](#sources)

## Définition

Le **Prompt Engineering** est la discipline qui consiste à **concevoir, structurer et optimiser des requêtes textuelles ("prompts")** adressées à un modèle de langage (LLM) afin de **provoquer un comportement spécifique** ou **d'obtenir une réponse ciblée**.

Un bon prompt :

* réduit l'ambiguïté
* limite les hallucinations
* structure la sortie
* améliore la robustesse
* guide le raisonnement

Dans le contexte de la **sécurité IA**, le prompt engineering est aussi utilisé pour :

- Tester les **capacités de résistance** des modèles aux attaques textuelles (e.g. prompt injection)
- Déclencher des comportements non souhaités dans un but **d'évaluation des risques** (red teaming)
- **Contourner les garde-fous** éthiques ou fonctionnels mis en place dans des IA conversationnelles

Voir la section [Sécurité & Prompt Injection](securite/) pour un approfondissement pratique.

## Concepts fondamentaux

### System prompt vs User prompt

Les LLM distinguent deux types de messages :

* **System prompt** : instructions données au modèle pour définir son comportement, son rôle et ses contraintes. Il n'est pas visible par l'utilisateur final. C'est ici qu'on place le cadrage (ton, format, restrictions).
* **User prompt** : la requête de l'utilisateur.

Cette séparation permet de sécuriser le comportement du modèle : le system prompt a priorité sur le user prompt.

### Temperature et paramètres

La **temperature** contrôle le degré d'aléatoire dans les réponses :

| Temperature | Comportement | Usage |
|-------------|-------------|-------|
| 0 | Déterministe, réponses reproductibles | Extraction de données, classification, code |
| 0.3 - 0.7 | Équilibre créativité / cohérence | Rédaction, résumé, dialogue |
| 1+ | Très créatif, moins prévisible | Brainstorming, génération d'idées |

Autres paramètres utiles : **top_p** (nucleus sampling), **max_tokens** (longueur max de la réponse), **stop sequences** (arrêter la génération à un mot-clé).

## Les grands principes

### Principe 0 : Faire attention aux hallucinations

Avoir un regard critique et ne pas adopter une confiance aveugle

### Principe 1 : Write clear and specific instructions

Un prompt clair ne veut pas dire court. Plus le contexte et les contraintes sont explicites, plus la réponse sera précise. L'objectif est de ne laisser aucune place à l'interprétation ambiguë par le modèle.

> 📓 Voir le notebook [01-guidelines](fondamentaux/notebooks/01-guidelines.ipynb) pour des exemples pratiques.

### Principe 2 : Give the model time to "think"

Les LLM raisonnent mieux quand on les force à :

* Décomposer le problème
* Expliquer leurs étapes
* Justifier leur réponse

## Les techniques

### Pour la clarté

1) **Utiliser des délimiteurs** : Permet de séparer clairement les parties du prompt => Réduit les erreurs d'interprétation.

2) **Demander une sortie structurée** : JSON, HTML => Facilite le parsing et évite les réponses imprévisibles

3) **Vérification des conditions** : Demander au modèle de vérifier avant de répondre => Réduit les hallucinations

4) **Zero-shot prompting** : Donner la tâche sans aucun exemple. Fonctionne bien pour des tâches simples ou quand le modèle a déjà une bonne compréhension du domaine.

5) **Few-shot prompting** : Donner des exemples avant la tâche => Stabilise la réponse et améliore la cohérence. Plus efficace que le zero-shot pour des tâches complexes ou des formats de sortie spécifiques.

6) **Negative prompting** : Préciser explicitement ce que le modèle ne doit **pas** faire. Utile pour éviter des comportements récurrents indésirables (ex : "Ne commence pas ta réponse par 'En tant que...'", "N'invente pas de sources").

### Pour le raisonnement

1) **Spécifier les étapes** : Forcer la décomposition

2) **Forcer le raisonnement explicite**

## Prompting Itératif

Le prompt engineering est un processus itératif :

* Tester
* Analyser la réponse
* Ajuster
* Réessayer

> 📓 Voir le notebook [02-iterative-prompt-development](fondamentaux/notebooks/02-iterative-prompt-development.ipynb)

<p align="center">
  <img src="./images/iterative_prompt.png" alt="Description" width="500"/>
</p>

## Problèmes fréquents et solutions

### Problème 1 : Réponse trop longue

Il faudra :

* Limiter le nombre de mots
* Limiter le nombre de phrases
* Fixer un nombre de caractères

### Problème 2 : Mauvais focus

Il faudra préciser sur quoi le LLM doit travailler.

### Problème 3 : Besoin d'un tableau

Là encore, le préciser

## Résumé (Summarization)

Différentes stratégies :

* Résumer en 1 phrase
* Résumer en 3 bullet points
* Résumer avec focus spécifique
* Utiliser "extract" plutôt que "summarize"

> 📓 Voir le notebook [03-summarizing](fondamentaux/notebooks/03-summarizing.ipynb)

## Inférence

L'inférence consiste à faire déduire une information implicite au modèle à partir d'un texte donné.

On ne demande pas de répéter le texte.
On demande d'interpréter.

Exemples :

* Analyse de sentiment
* Détection d'émotion
* Classification
* Détection d'intention

> 📓 Voir le notebook [04-inferring](fondamentaux/notebooks/04-inferring.ipynb)

## Transformation

Les LLM peuvent transformer du contenu :

* Traduction
* Changement de ton
* Conversion de format
* Reformulation

> 📓 Voir le notebook [05-transforming](fondamentaux/notebooks/05-transforming.ipynb)

## Techniques avancées

1) **Chain-of-Thought (CoT) Prompting** : Forcer l'explication du raisonnement étape par étape. On peut l'activer avec "Let's think step by step" ou en montrant un exemple de raisonnement.

2) **Tree of Thought (ToT)** : Extension du CoT. Le modèle explore **plusieurs pistes de raisonnement en parallèle**, évalue chaque branche, et sélectionne la meilleure. Utile pour des problèmes complexes où un seul chemin de pensée peut mener à une impasse.

3) **ReAct (Reasoning + Acting)** : Le modèle alterne entre **raisonner** (Thought), **agir** (Action, ex : chercher dans une base) et **observer** (Observation, le résultat de l'action). C'est le pattern fondamental derrière les agents IA.

4) **Prompt Chaining** : Décomposer une tâche complexe en **plusieurs prompts enchaînés**, où la sortie de l'un devient l'entrée du suivant. Chaque étape est plus simple et plus contrôlable qu'un seul prompt monolithique.

5) **Role Prompting** : Attribuer un rôle au modèle (ex : "Tu es un data scientist senior") pour orienter le ton, le vocabulaire et le niveau de détail de la réponse.

6) **Constraint Prompting** : Imposer des règles strictes (format, longueur, vocabulaire autorisé, etc.)

7) **Self-Consistency** : Demander plusieurs raisonnements et choisir la réponse la plus fréquente. Réduit les erreurs aléatoires.

8) **Negative Prompting** : Spécifier ce que le modèle ne doit pas faire. Complémentaire aux instructions positives.

> 📓 Voir aussi les notebooks [06-expanding](fondamentaux/notebooks/06-expanding.ipynb) et [07-chatbot](fondamentaux/notebooks/07-chatbot.ipynb) pour des exemples d'application.

## Gestion des Hallucinations

Stratégies :

* Ajouter : "If unsure, say I don't know"
* Forcer l'utilisation du contexte
* Utiliser un RAG (Retrieval-Augmented Generation)
* Ajouter une étape de vérification
* Utiliser le negative prompting : "N'invente pas d'informations"

## Sources

Voir la liste complète des sources dans le [README principal](README.md#sources--credits).
