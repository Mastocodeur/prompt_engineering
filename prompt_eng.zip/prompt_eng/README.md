# Prompt Engineering

[![English](https://img.shields.io/badge/lang-English-blue)](README_EN.md)

> Un repo de reference sur le prompt engineering : principes, techniques, exercices pratiques et securite des LLM.

---

## Sommaire

- [Fiche recapitulative](#-fiche-recapitulative)
- [Fondamentaux](#-fondamentaux)
- [Securite & Prompt Injection](#-securite--prompt-injection)
- [Sources & Credits](#-sources--credits)

---

## Fiche recapitulative

**[FICHE.md](FICHE.md)** — Cheat sheet complet sur le prompt engineering :

- Principes fondamentaux (instructions claires, raisonnement)
- Techniques : few-shot, chain-of-thought, role prompting, constraint prompting
- Prompting iteratif
- Problemes frequents et solutions
- Resume, inference, transformation
- Gestion des hallucinations

---

## Fondamentaux

**[fondamentaux/](fondamentaux/)** — 7 notebooks issus du cours [ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) de DeepLearning.AI.

| # | Notebook | Theme |
|---|----------|-------|
| 01 | Guidelines | Principes de base |
| 02 | Iterative Prompt Development | Processus iteratif |
| 03 | Summarizing | Techniques de resume |
| 04 | Inferring | Sentiment, classification |
| 05 | Transforming | Traduction, ton, format |
| 06 | Expanding | Generation de texte |
| 07 | Chatbot | Chatbot avec contexte |

---

## Securite & Prompt Injection

**[securite/](securite/)** — Exploration du prompt engineering offensif et defensif a travers le jeu [Gandalf](https://gandalf.lakera.ai/) de Lakera.

- [**Introduction & contexte**](securite/README.md) — Qu'est-ce que la prompt injection ? Incidents reels.
- [**Techniques d'attaque**](securite/TECHNIQUES.md) — Boite a outils : ~30 techniques classees (injection directe, jailbreak, obfuscation, encodage, etc.)
- [**Solutions Gandalf**](securite/SOLUTIONS.md) — Walkthrough complet : niveaux 1-8 + variantes (Summarizer, Truthteller, Reverse, Tongue Tied)

---

## Sources & Credits

### Cours & formations

- [ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) — DeepLearning.AI (Andrew Ng & Isa Fulford)

### Securite IA

- [Gandalf](https://gandalf.lakera.ai/) — Lakera
- [Prompt Guard (fine-tuned)](https://huggingface.co/skshreyas714/prompt-guard-finetuned) — HuggingFace

### Guides & ressources

- [Prompt Engineering Guide](https://github.com/dair-ai/Prompt-Engineering-Guide) — DAIR.AI
- [Awesome GPT Prompts](https://www.awesomegptprompts.com/)
- [Prompt Guide](https://docs.perplexity.ai/docs/agent-api/prompt-guide) — Perplexity AI
- [GPT Prompts for Data](https://notion.castordoc.com/gpt-prompts) — CastorDoc
