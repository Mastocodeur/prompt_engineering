# Prompt Engineering Fundamentals

These notebooks are from the [**ChatGPT Prompt Engineering for Developers**](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) course by **DeepLearning.AI**, co-taught by Andrew Ng and Isa Fulford (OpenAI).

## Notebooks

| # | Notebook | Description |
|---|----------|-------------|
| 01 | [Guidelines](notebooks/01-guidelines.ipynb) | Core principles: clear instructions, delimiters, structured outputs |
| 02 | [Iterative Prompt Development](notebooks/02-iterative-prompt-development.ipynb) | Iterative process: test, analyze, refine |
| 03 | [Summarizing](notebooks/03-summarizing.ipynb) | Summarization techniques: focus, length, extraction |
| 04 | [Inferring](notebooks/04-inferring.ipynb) | Inference: sentiment, classification, entity extraction |
| 05 | [Transforming](notebooks/05-transforming.ipynb) | Transformation: translation, tone, format, proofreading |
| 06 | [Expanding](notebooks/06-expanding.ipynb) | Expansion: generating text from short instructions |
| 07 | [Chatbot](notebooks/07-chatbot.ipynb) | Building a chatbot with context management |
