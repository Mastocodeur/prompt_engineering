# Fondamentaux du Prompt Engineering

[![English](https://img.shields.io/badge/lang-English-blue)](README_EN.md)

Ces notebooks sont issus du cours [**ChatGPT Prompt Engineering for Developers**](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) de **DeepLearning.AI**, co-anime par Andrew Ng et Isa Fulford (OpenAI).

## Notebooks

| # | Notebook | Description |
|---|----------|-------------|
| 01 | [Guidelines](notebooks/01-guidelines.ipynb) | Principes de base : instructions claires, delimiteurs, sorties structurees |
| 02 | [Iterative Prompt Development](notebooks/02-iterative-prompt-development.ipynb) | Processus iteratif : tester, analyser, ajuster |
| 03 | [Summarizing](notebooks/03-summarizing.ipynb) | Techniques de resume : focus, longueur, extraction |
| 04 | [Inferring](notebooks/04-inferring.ipynb) | Inference : sentiment, classification, extraction d'entites |
| 05 | [Transforming](notebooks/05-transforming.ipynb) | Transformation : traduction, ton, format, correction |
| 06 | [Expanding](notebooks/06-expanding.ipynb) | Expansion : generation de texte a partir de consignes courtes |
| 07 | [Chatbot](notebooks/07-chatbot.ipynb) | Construction d'un chatbot avec gestion du contexte |
